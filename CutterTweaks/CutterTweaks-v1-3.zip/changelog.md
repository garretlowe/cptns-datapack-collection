1.3
- Added Mangrove recipes
- Added Mud Bricks recipe
- Added Wood to Planks recipes
- Added Wood to Stripped Wood recipes

1.2
- Added More Stone recipes
- Added Deepslate recipes

1.1
- Changed Fence Gate recipes to yield 1 gate per block

1.0
- Initial release